#include<stdio.h>
int main()
{
int num;
printf("Enter any number");
scanf("%d",&num);
printf("The number without last digit is:%d",num/10);
return 0;
}

