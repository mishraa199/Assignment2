#include <stdio.h>

int main ()
{
    int number,reverse=0,reminder=0;
    printf("Enter any number");
    scanf("%d",&number);
    while (number>0)
    {
        reminder=number%10;
        reverse=reverse*10+reminder;
        number=number/10;
    }
    printf("%d",reverse);
    return 0;
}
