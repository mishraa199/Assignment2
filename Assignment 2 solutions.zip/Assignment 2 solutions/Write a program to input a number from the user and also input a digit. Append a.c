#include <stdio.h>

int main ()
{
    int num,digit;
    printf("Enter any number and digit");
    scanf("%d %d",&num,&digit);
    num= num*10+digit;
    printf("%d",num);
    return 0;

}
