#include <stdio.h>

int main()
{
    int num;
    printf("Enter a number");
    scanf("%d",&num);
    printf(" Last digit of this number %d",num%10);

    return 0;
}
