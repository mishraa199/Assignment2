#include <stdio.h>

int main ()
{
    float dollers, indianrupees;
    printf("Enter indianrupees");
    scanf("%f",&indianrupees);
    dollers= indianrupees/76.23;
    printf("dollers is %f",dollers);
    return 0;
}
