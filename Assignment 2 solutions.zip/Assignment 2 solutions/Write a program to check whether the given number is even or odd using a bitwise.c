#include <stdio.h>

int main()
{
    int num, result=0;
    printf("Enter a number");
    scanf("%d",&num);
    result= num&1;
    if (result==0)
    {
        printf("Even Number");
    }
     else
            printf("Odd Number");

    return 0;
}
