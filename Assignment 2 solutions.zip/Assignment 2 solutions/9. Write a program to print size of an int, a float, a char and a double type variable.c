#include <stdio.h>

int main ()
{
    int inttype;
    char chartype;
    double doubletype;
    float floattype;

    printf("Size of the int: %lu bytes\n", sizeof(inttype));
    printf("Size of the char: %lu bytes\n", sizeof(chartype));
    printf("Size of the double: %lu bytes\n", sizeof(doubletype));
    printf("Size of the float: %lu bytes", sizeof(floattype));
    return 0;
}
