#include <stdio.h>
int main()
{
    char b= 'C';
    printf("ASCII code is %d",b);
    return 0;
}
