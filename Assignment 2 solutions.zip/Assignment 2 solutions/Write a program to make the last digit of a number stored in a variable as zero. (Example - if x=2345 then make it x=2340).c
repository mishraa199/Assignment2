#include <stdio.h>
int main ()
{
    int num, digit;
    printf("Enter a number");
    scanf("%d",&num);
     num= num/10;
     num= num*10;
    printf("Number %d",num);
    return 0;
}
